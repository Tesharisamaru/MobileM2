package fr.mastersid.rio.stackoverflow.view
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.LineHeightStyle
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import fr.mastersid.rio.stackoverflow.R
import fr.mastersid.rio.stackoverflow.data.Question

@Composable
fun QuestionScreen() {
    val questionList = rememberSaveable {
        mutableStateOf(
            listOf(
                //Question(id,title,answerCount)
                Question(1, "AndroidStudioInstall", 50),
                Question(7, "ColconBuild", 10)
            )
        )
    }

    Box {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(questionList.value) { question ->
                Row {
                    Text(
                        text = "${question.id}",
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(16.dp))
                    Text(text = "${question.title}")
                    Spacer(modifier = Modifier.width(16.dp))
                    Text(text = " ${question.answerCount}")
                }
            }
        }
        Button(
            onClick = {
                questionList.value = listOf(
                    Question(1, "AndroidStudioInstall", 50),
                    Question(7, "ColconBuild", (1..9).random()),
                    Question(8, "MajView", 650)
                )
            },
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text("Update list")
        }
    }
}